#include "my_solver.h"

extern double (*_f)(double);
extern double (*_fp)(double);

/*********************************************
  Newton-Rapson Method
**********************************************/
void program1_1(FILE* fp) {
	double x0, x1;
	int n = 0;
	//int count = 0;
	//int N_max = Nmax;
	if (fp == NULL)
		return;
	printf("input x_0 : ");
	scanf("%lf", &x0);

	fprintf(fp,"n		 x			|f(x)|\n");

	while (n < Nmax) {
		double _fx = _f(x0);

		fprintf(fp,"%-2d %25.15e %25.15e\n",n, x0, fabs(_fx));
		if (fabs(_fx) < DELTA) break;

		x1 = x0 - (_fx / _fp(x0));

		if (fabs(x1 - x0) < EPSILON) break;

		x0 = x1;
		n++;
	}
	printf("%25.15e\n", x0);
	//scanf �Է°� �ް� ��ư ���ñ� ȣ�� _f _f
}
