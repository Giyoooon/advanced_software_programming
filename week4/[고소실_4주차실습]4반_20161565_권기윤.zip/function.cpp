#define _USE_MATH_DEFINES
#include <math.h>

double _f1(double x) {
	double result ;
	result = (x * x) - (4.0 * x) + 4.0 - log(x);
	return result;
}

double _fp1(double x) {
	
	double result;
	result = (2 * x) - 4.0 - (1.0 / x);
	return result;
}

double _f2(double x) {
	// f2 = x +1 -2sin(PI*x) = 0
	double result;
	result = x + 1.0 - 2 * sin(M_PI * x);
	return result;
}

double _fp2(double x) {
	// f2 = x +1 -2sin(PI*x) = 0
	double result;
	result = 1.0 - 2 * M_PI * cos(M_PI * x);
	return result;
}

double _f3(double x) {
	double result;
	result = (x * x * x * x) - 11.0 * (x * x * x) + 42.35 * (x * x) - 66.55 * x + 35.1384;
	return result;
}

double _fp3(double x) {
	double result;
	result = 4 * (x * x * x) - 11.0 * 3 * (x * x) + 42.35 * 2 * x - 66.55;
	return result;
}

double _f_sqrt(double x) {
	return x * x - 2.0;
}

double _fp_sqrt(double x) {
	return 2.0 * x;
}

double _f_vehicle(double x) {
	return 0.0;
}

double _fp_vehicle(double x) {
	return 0.0;
}

double _f_comp(double x) {
	double result;
	result = log(x) - 1.0;
	return result;
}

double _fp_comp(double x) {
	double result;
	result = 1.0 / x;
	return result;
}
