﻿#include "my_solver.h"

int main(void)
{
    //assignment3_1();
    //assignment3_2();
    assignment3_3();
    //assignment3_4();

    return 0;
}
