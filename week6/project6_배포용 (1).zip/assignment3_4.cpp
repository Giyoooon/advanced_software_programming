#include "my_solver.h"
#define MAX_N 32

void assignment3_4() {
	char fn_r1[256];
	char fn_r2[256];
	char fn_w1[256];
	char fn_w2[256];
	int cnt;
	int index[10] = {2,3,4,5,7,9,12,16,24,32};
	for (cnt = 0; cnt < 10; cnt++) {
		sprintf(fn_r1, "General_%d.txt",index[cnt]);
		sprintf(fn_r2, "Hilbert_%d.txt", index[cnt]);

		sprintf(fn_w1, "General_%d_result.txt", index[cnt]);
		sprintf(fn_w2, "Hilbert_%d_result.txt", index[cnt]);

		FILE* fp_r1, * fp_r2, *fp_w1, *fp_w2;
		fp_r1 = fopen(fn_r1,"r");
		fp_r2 = fopen(fn_r2, "r");
		fp_w1 = fopen(fn_w1, "w");
		fp_w2 = fopen(fn_w2, "w");

		if (fp_r1 == NULL) {
			printf("%s : cannt open file.\n", fn_r1);
			return;
		}
		if (fp_r2 == NULL) {
			printf("%s : cannt open file.\n", fn_r2);
			return;
		}
		if (fp_w1 == NULL) {
			printf("%s : cannt open file.\n", fn_w1);
			return;
		}
		if (fp_w2 == NULL) {
			printf("%s : cannt open file.\n", fn_w2);
			return;
		}


	}
	
}